select Column_list
from table_name
order by column1;

select * from customers;

-- Order by single column
select contactlastname,
		contactfirstname
from customers
order by contactlastname desc;

-- Order by multiple column
select contactlastname,
		contactfirstname
from customers
order by contactlastname desc,
		contactfirstname asc;
        
select * from orderdetails;
-- order by expression
select ordernumber,
		orderlinenumber,
		quantityordered * priceeach
from 
	orderdetails
order by quantityordered * priceeach asc;

SELECT FIELD ( 'C', 'A', 'B', 'C');
SELECT * FROM ORDERS;

SELECT ordernumber, status
from orders
order by field(status, 'In Process',
						'On Hold',
						'Cancelled',
                        'Resolved',
                        'Disputed',
                        'Shipped');
select reportsto from employees ;

select * from employees;
-- Null values are lower than non-null values

select firstname, lastname, reportsto
from employees
order by reportsto desc;