-- Column alias
select  concat_ws(',' , lastname, firstname) 'FullName'
from employees
order by 'FullName';


select  * from orderdetails;

select ordernumber 'Order no.',
		sum(PriceEach * quantityordered) total
from orderdetails
group by 'Order no.'
having total > 60000;

-- table alias

select * from employees e;

select e.firstname,
		e.lastname
from employees e
order by e.firstName;