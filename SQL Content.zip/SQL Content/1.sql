-- Single Column
SELECT lastname
FROM employees;

-- Multiple Columns
SELECT  lastname as ln,
		firstname as fn,
        jobTitle as Jt
FROM employees;

-- All Column
Select *
FROM employees;

SELECT 1+1;
SELECT NOW();
SELECT CONCAT('Prateek', ' ' , 'Chugh') as fullname;
