-- distinct with single column
select DISTINCT lastname
from employees
order by lastname;

SELECT state from customers;

-- -- distinct with mutiple column
select distinct state, city
from customers
where state  is not null
order by state, city;

SELECT 1 AND 0;
SELECT 1 AND NULL;