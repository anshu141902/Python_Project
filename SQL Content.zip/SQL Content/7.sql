-- Inner Join two tables
/* select select_list
from t1
inner join t2 on join_conditin; */
select * from products;
select * from productlines;

select productcode,
		productname,
		textdescription
from products t1
INNER JOIN productlines t2
	ON t1.productLine = t2.productLine;


-- Inner join using group by
select * from orders;
select * from orderdetails;
select * from products;
select * from customers;
select orderNumber,
		orderdate,
		orderLineNumber,
		quantityOrdered,
		priceEach
from orders 
inner join orderdetails 
using (ordernumber);


-- Inner Join three tables

select orderNumber,
		orderdate,
		orderLineNumber,
        productname,
		quantityOrdered,
		priceEach
from orders 
inner join orderdetails 
using (ordernumber)
inner join products
using (productcode)
order by
	ordernumber;

select ordernumber, status, quantityordered, priceEach
from orders inner join orderdetails
using (ordernumber)
group by ordernumber;

-- Inner Join Four tables
select orderNumber,
		orderdate,
		orderLineNumber,
        productname,
		quantityOrdered,
		priceEach,
        customerName
from orders 
inner join orderdetails 
using (ordernumber)
inner join products
using (productcode)
inner join customers
using (customernumber)
order by
	ordernumber;
-- Inner join using other operators
/*Find the sales price of the product whose code is S10_1678 that is less than 
the manufacturer’s suggested retail price (MSRP) for that product */
select * from orderdetails;
select * from products;
explain
select ordernumber,
		productName,
        msrp,
        priceEach
from products p
inner join orderdetails o
on p.productcode = o.productCode
	and p.msrp > o.priceeach
where 
	p.productcode = 'S10_1678';

-- Left Join
-- left join = inner join + data from left table
/* select select_list
from t1
left join t2 on join_conditin; */
select * from customers;
select * from orders;
select  customers.customerNumber,
		customerName,
		ordernumber,
        status
from customers
left join orders on
	orders.customernumber = customers.customernumber
where 
	orderNumber is null;



-- find all customers and their orders

-- LEFT JOIN clause to find unmatched rows
-- LEFT JOIN to join three tables
select lastname,
		firstname,	customerName,amount
from employees
left join customers on
	employeenumber = salesrepemployeenumber
left join payments on
	payments.customernumber = customers.customernumber
order by customerName;



-- Condition in WHERE clause vs. ON clause

-- Right Join
/* select select_list
from t1
right join t2 on join_conditin; */

select employeenumber, customernumber
from customers
right join employees
on salesRepEmployeeNumber = employeenumber
where customernumber is null
order by employeenumber;

-- RIGHT JOIN to find unmatching rows

-- Self Join
select * from employees;
select ifnull(concat(m.lastname, ',', m.firstname), 'TopManager') as manager,
		concat(e.lastname, ',', e.firstname) as 'Direct Report'
from employees e
left join employees m on
	m.employeenumber = e.reportsto
order by manager desc;

-- self join using INNER JOIN clause
-- Find the employees who have a manager

-- self join using LEFT JOIN clause

-- self join to compare successive rows
select * from customers;
select c1.city,
		c1.customerName,
		c2.customerName
from customers c1
inner join customers c2 on
	c1.city = c2.city
    and c1.customerName > c2.customerName
order by city;


-- Find a list of customers who locate in the same city

select * from orders;

select status, count(*)
from orders
group by status;

select * from orders;
select * from orderdetails;

select status, sum(quantityOrdered * priceEach) amount
from
orders
inner join orderdetails
	using (ordernumber)
group by status;
