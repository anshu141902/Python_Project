-- Subquery
-- Find the employees who work in the offices located in the USA.
select lastname, firstname
from employees where officeCode in (
select officecode from offices where country = 'USA');


-- subquery in the WHERE clause
-- Find the customer who has the highest payment
select *
from payments;

select customernumber,
		checkNumber,
        amount
from payments
where amount = (select max(amount) from payments);

-- Find customers whose payments are greater than the average payment using a subquery:
select customernumber,
		checkNumber,
        amount
from payments
where amount > (select avg(amount) from payments);
-- subquery with IN and NOT IN operators
-- customer who have not placed any order
select customername
from customers
where customerNumber not in (select distinct customerNumber from orders);

-- subquery in the FROM clause
-- Maximum , minimum and average number of items in sales order


select 
max(items),
min(items),
floor(avg(items))
from(
select ordernumber, count(ordernumber) as items
from orderdetails
group by orderNumber) as lineitems;


-- correlated subquery


-- Find the products whose buy prices are greater than the average buy price of all products in each product line.

-- subquery with EXISTS and NOT EXISTS
-- finds sales orders whose total values are greater than 60K.
-- find customers who placed at least one sales order with the total value greater than 60K 