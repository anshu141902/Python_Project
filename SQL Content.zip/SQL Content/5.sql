-- in operator
select * from offices;
select officecode,
		city,
		phone,
        country
from offices
where country not in ('USA' ,'France');

-- Like %
select firstname,
		lastname,
		employeenumber
from employees
where lastname not Like '%on%';

-- Like Underscore
select firstname,
		lastname,
		employeenumber
from employees
where firstname Like 'T_m';

select * from products;
-- Escape Clause
select productcode,
		productname
from products
where productcode LIKE '%\_20%' ;

-- Limit
select column1
from table_name
limit (offset, rowcount);

select * from customers;

select customernumber,
		customername,
        creditLimit
from customers
order by creditlimit desc
limit 1,1;

/* select columnname
from tablename
order by sort
limit n-1,1 */

