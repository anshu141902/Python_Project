-- Where clause
select * from employees;
-- where clause equality operator
select firstname,
		lastname,
		jobtitle
from employees
where jobtitle = 'Sales Rep';

-- where clause AND operator

select firstname,
		lastname,
		jobtitle
from employees
where jobtitle = 'Sales Rep'
		and officecode = 1;
        
-- where clause or operator

select firstname,
		lastname,
		jobtitle
from employees
where jobtitle = 'Sales Rep'
		or officecode = 1;

-- where clause AND operator

-- between low and high
select firstname,
		lastname,
		officeCode
from employees
where  officecode between 1 and 3
order by officeCode;

-- Like operator
select firstname,
		lastname
from employees
where  lastname LIKE '%son'
order by firstname;

-- value in
select firstname,
		lastname,
		officeCode
from employees
where  officecode in ( 1,2,3)
order by officeCode;

-- IS NULL OPERATOR 

select firstname, lastname, reportsto
from employees
WHERE reportsto IS NULL;

-- comparison operator

select firstname,
		lastname,
		jobtitle
from employees
where jobtitle <> 'Sales Rep';

select firstname,
		lastname,
		officecode
from employees
where officeCode <= 4;